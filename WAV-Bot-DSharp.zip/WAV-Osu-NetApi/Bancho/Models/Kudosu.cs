﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.Models
{
    public class Kudosu
    {
        public double available { get; set; }
        public double total { get; set; }
    }
}
