﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.Models
{
    public class Cover
    {
        public string custom_url { get; set; }
        public string url { get; set; }
        public string id { get; set; }
    }
}
