﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.Models
{
    public class Failtimes
    {
        public List<int> exit { get; set; }
        public List<int> fail { get; set; }
    }
}
