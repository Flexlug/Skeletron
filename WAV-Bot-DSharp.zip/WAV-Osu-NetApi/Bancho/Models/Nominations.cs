﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.Models
{
    public class Nominations
    {
        public int current { get; set; }
        public int required { get; set; }
    }
}
