﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.Models
{
    public class Availability
    {
        public bool download_disabled { get; set; }
        public string more_information { get; set; }
    }
}
