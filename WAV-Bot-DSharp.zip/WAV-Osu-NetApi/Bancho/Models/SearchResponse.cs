﻿using System;
using System.Text;
using System.Collections.Generic;

namespace WAV_Osu_NetApi.Bancho.Models
{
    public class SearchResponse
    {
        public List<Beatmapset> Beatmapsets { get; set; }
    }
}
