﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.Models
{
    public class Country
    {
        public string code { get; set; }
        public string name { get; set; }
    }
}