﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.QuerryParams
{
    public enum MapMode
    {
        Std = 0,
        Taiko = 1,
        Ctb = 2,
        Mania = 3
    }
}
