﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_NetApi.Bancho.QuerryParams
{
    public enum MapType
    {
        Any,
        Ranked,
        Qualified,
        Loved,
        Pending,
        Graveyard,
        Mine
    }
}
