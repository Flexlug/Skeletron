﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Osu_Recognizer_Test
{
    public class Settings
    {
        public int ClientId { get; set; }
        public string Secret { get; set; }
    }
}
