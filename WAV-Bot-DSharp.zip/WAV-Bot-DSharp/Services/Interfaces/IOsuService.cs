﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WAV_Bot_DSharp.Services.Interfaces
{
    public interface IOsuService
    {
    }
}
